export { default as ViewWorkslots } from "./view-workslots.component";
