export { default as StaffWorkslots } from "./staff-workslots.component";
