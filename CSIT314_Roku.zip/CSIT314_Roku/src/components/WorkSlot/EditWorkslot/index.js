export { default as EditWorkslot } from "./edit-workslot.component";
