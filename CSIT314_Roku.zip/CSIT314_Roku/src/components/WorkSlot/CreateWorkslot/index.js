export { default as CreateWorkslot } from "./create-workslot.component";
