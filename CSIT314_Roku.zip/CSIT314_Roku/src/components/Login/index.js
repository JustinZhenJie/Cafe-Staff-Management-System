export { default as Login } from "./login.component";
