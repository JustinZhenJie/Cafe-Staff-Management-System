export { default as NavbarComponent } from "./navbar-component.component";
