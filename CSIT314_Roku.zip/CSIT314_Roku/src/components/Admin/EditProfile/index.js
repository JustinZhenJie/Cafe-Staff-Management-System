export { default as EditProfile } from "./edit-profile.component";
