export { default as CreateUser } from "./create-user.component";
