export { default as ViewUser } from "./view-user.component";
