export { default as ViewProfiles } from "./view-profiles.component.js";
